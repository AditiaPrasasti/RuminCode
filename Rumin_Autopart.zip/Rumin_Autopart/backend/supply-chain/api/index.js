import app from '../src/app'
export default app