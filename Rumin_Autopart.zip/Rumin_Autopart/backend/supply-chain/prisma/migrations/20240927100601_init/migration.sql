-- DropIndex
DROP INDEX "Supplier_user_id_key";
